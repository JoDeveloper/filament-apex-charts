<?php

namespace Jodeveloper\FilamentApexCharts;

class FilamentApexCharts {}
