<?php

return [
    'reset' => [
        'label' => 'Reset',
    ],
];
